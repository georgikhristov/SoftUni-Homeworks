﻿//Declare a Boolean variable called isFemale and assign 
//an appropriate value corresponding to your gender. 
//Print it on the console.

using System;

class BooleanVariable
{
    static void Main()
    {
        bool isFemale = true;
        Console.WriteLine(isFemale);
    }
}