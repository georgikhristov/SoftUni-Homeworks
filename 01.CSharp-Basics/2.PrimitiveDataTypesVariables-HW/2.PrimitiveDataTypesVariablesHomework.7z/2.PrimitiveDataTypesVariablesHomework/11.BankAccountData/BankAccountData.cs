﻿//A bank account has a holder name (first name, middle name and last name), 
//available amount of money (balance), bank name, IBAN, 
//3 credit card numbers associated with the account. 
//Declare the variables needed to keep the information for a single bank account 
//using the appropriate data types and descriptive names.
//A bank account has a holder name (first name, middle name and last name), 
//available amount of money (balance), bank name, IBAN, 3 credit card numbers associated with the account.
//Declare the variables needed to keep the information for a single bank account
//using the appropriate data types and descriptive names.


using System;
class BankAccountData
{
    static void Main(string[] args)
    {
        string firstName = "Ivan";
        string middleName = "Ivanov";
        string lastName = "Georgiev";
        decimal balance= 1200.23m;
        string bankName = "DSK";
        string IBAN;
        ulong firstCard;
        ulong secondCard;
        ulong thirdCard;
    }
}

