﻿function evenNumber(value) {
    if (value % 2 == 0) {
        console.log(value + " is even? " + "true");
    } else {
        console.log(value + " is even? " + "false");
    }
}

evenNumber(3);
evenNumber(127);
evenNumber(588);