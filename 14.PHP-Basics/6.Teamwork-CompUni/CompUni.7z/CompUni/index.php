<?php
require("includes/connect.php");
require("includes/headerForm.php");
require("includes/categoriesForm.php");
require("includes/topicsForm.php");
require("includes/footerForm.php");
?>