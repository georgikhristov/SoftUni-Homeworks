</div> <!--div Container-->
</section> <!--Section-tout -->



<footer class="footer">
    <div class="container">
	<span class="fb-like" data-href="https://www.facebook.com/CompUniForum?notif_t=fbpage_fan_invite" data-layout="button_count" data-action="like" data-show-faces="true" data-share="true"></span>
            <span class="pull-right clearfix">
                <span class="glyphicon glyphicon-copyright-mark"></span>
                CopyRight CompUni
            </span>
    </div>

</footer>

<script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/bootswatch.js"></script>
</body>
</html>