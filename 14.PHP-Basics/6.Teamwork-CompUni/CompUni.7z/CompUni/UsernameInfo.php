<?php
require ("includes/connect.php");
require("includes/headerForm.php");
require("includes/UsernameInfoForm.php");
require("includes/footerForm.php");
?>