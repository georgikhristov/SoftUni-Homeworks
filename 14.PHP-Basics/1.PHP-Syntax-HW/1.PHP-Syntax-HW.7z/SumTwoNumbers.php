<?php
$firstNumber = 5.2;
$secondNumber = 3;
$sum = $firstNumber + $secondNumber;
?>
<div>$firstNumber + $secondNumber = <?= $firstNumber?> + <?= $secondNumber?> = <?= $sum?></div>