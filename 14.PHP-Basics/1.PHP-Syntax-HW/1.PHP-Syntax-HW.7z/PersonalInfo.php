<?php
$firstName = 'Tsvetina';
$lastName = 'Georgieva';
$age = 20;
$fullName = $firstName . ' ' . $lastName;
?>
<div>My name is <?=$fullName ?> and I am <?=$age?> years old.</div>